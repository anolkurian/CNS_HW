#include <fstream>

int main() {  
  std::ofstream outfile;

  outfile.open("sample.txt.ufsec", std::ios_base::app);
  outfile << "Data"; 
  return 0;
}