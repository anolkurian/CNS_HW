#ifndef OPENSSL_SOCKET_H
#define OPENSSL_SOCKET_H

#include <cstdint>
#include <vector>
#include <string>

using std::string;
using std::vector;

#define MAX_MSG_SIZE 4096

#define HEADER_SIZE (sizeof(uint32_t)+sizeof(uint16_t)+sizeof(uint16_t))

#define BLK_SIZE MAX_MSG_SIZE+HEADER_SIZE 

typedef struct 
{
	uint32_t seqNum;
	uint16_t msgSize;
	uint16_t finalBlk;
} msgHeader_t;

class OpensslSocket
{
public:
	OpensslSocket(const string recvPortNum, const string sendPortNum = "");
	~OpensslSocket();
	int Send(const string destIP, const char* msg, size_t msgLength);
	int Receive();
	void GetReceiveMessage(char* buffer, size_t bufferLength);
	
private:
	void BundleHeader(char* dest, msgHeader_t header);
	void FetchHeader(char* buffer, msgHeader_t* header);

	int sockFd;
	bool socketGood;
	string sendPort;
	string recvPort;
	vector<char> receiveBuffer;
	unsigned int receiveBufferLength;
	bool receiveBufferGood;
};

#endif //OPENSSL_SOCKET_H