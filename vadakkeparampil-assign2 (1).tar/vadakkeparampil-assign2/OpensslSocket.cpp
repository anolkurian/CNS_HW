
#include "OpensslSocket.h"
#include <arpa/inet.h>
#include <unistd.h>
#include <errno.h>
#include <iostream>
#include <cstring>
#include <algorithm>
#include <sys/time.h>
#include <netinet/in.h>
#include <netdb.h>
#include <sys/socket.h>
#include <sys/types.h>

using std::copy;
using std::cout;
using std::endl;
using std::string;

OpensslSocket::OpensslSocket(const string recvPortNum, const string sendPortNum)
{
	struct addrinfo hints, *addrInfo, *p;
	receiveBufferGood = false;
	socketGood = false;
	receiveBufferLength = 0;
	sendPort = sendPortNum;
	recvPort = recvPortNum;

	/* set addrinfo values */
	memset(&hints, 0, sizeof hints);
	hints.ai_family = AF_INET;
	hints.ai_socktype = SOCK_DGRAM;
	hints.ai_flags = AI_PASSIVE;

	if (getaddrinfo(NULL, recvPort.c_str(), &hints, &addrInfo) != 0)
	{
		cout << "Error in OpensslSocket Constructor: getaddrinfo()" << endl;
		return;
	}

	for (p = addrInfo; p != NULL; p = p->ai_next)
	{
		cout << addrInfo << endl;
		if ((sockFd = socket(p->ai_family, p->ai_socktype, p->ai_protocol)) == -1)
			continue;

		if (bind(sockFd, p->ai_addr, p->ai_addrlen) == -1)
		{
			close(sockFd);
			cout << "Error in OpensslSocket Constructor: bind()" << endl;
			perror("Errno Message");
			continue;
		}
		break;
	}

	if (p == NULL)
		cout << "Error in OpensslSocket Constructor: failed to bind" << endl;
	else
	{
		freeaddrinfo(addrInfo);
		socketGood = true;
	}
}

OpensslSocket::~OpensslSocket()
{
	if (socketGood)
		close(sockFd);
}
void OpensslSocket::FetchHeader(char *buffer, msgHeader_t *header)
{
	uint32_t seqNum_N;
	uint16_t msgSize_N;
	uint16_t finalBlk_N;

	/* compute the offset of the contents of the header */
	int msgOffset = sizeof(seqNum_N);
	int finalOffset = msgOffset + sizeof(msgSize_N);

	/* retrieve the contents of the header from the buffer */
	memcpy(&seqNum_N, buffer, sizeof(seqNum_N));
	memcpy(&msgSize_N, buffer + msgOffset, sizeof(msgSize_N));
	memcpy(&finalBlk_N, buffer + finalOffset, sizeof(finalBlk_N));

	/* convert the contents host order, store in the header */
	header->seqNum = ntohl(seqNum_N);
	header->msgSize = ntohs(msgSize_N);
	header->finalBlk = ntohs(finalBlk_N);
}
int OpensslSocket::Send(const string destIP, const char *msg, size_t msgLength)
{
	if (!socketGood)
		return -1;

	char recvIP[INET_ADDRSTRLEN];
	char sentIP[INET_ADDRSTRLEN];
	char sendHeader[HEADER_SIZE];
	char sendBlk[BLK_SIZE];
	char ack[HEADER_SIZE];
	int numBlks;
	struct sockaddr_in sendAddr, recvAddr;
	struct timeval ackTimeout;
	bool ackSeqNum;
	msgHeader_t msgHeader, recvMsgHeader;
	socklen_t sendAddrLen = sizeof(sendAddr);
	socklen_t recvAddrLen = sizeof(recvAddr);

	/* initialize the destination sockadd_in structure */
	memset(&sendAddr, 0, sizeof(sendAddr));
	sendAddr.sin_family = AF_INET;
	sendAddr.sin_port = htons(atoi(sendPort.c_str()));
	inet_pton(AF_INET, destIP.c_str(), &(sendAddr.sin_addr));

	/* determine total number of blocks for the message */
	numBlks = msgLength / MAX_MSG_SIZE;
	if (msgLength % MAX_MSG_SIZE)
		numBlks++;

	/* initialize message header */
	memset(&msgHeader, 0, sizeof(msgHeader));
	msgHeader.finalBlk = 0;
	msgHeader.seqNum = 0;
	msgHeader.msgSize = MAX_MSG_SIZE;

	/* save the destination IP address string, and set a timeout for receiving acks */
	inet_ntop(AF_INET, &(sendAddr.sin_addr), sentIP, INET_ADDRSTRLEN);
	ackTimeout.tv_sec = 1;
	ackTimeout.tv_usec = 0;
	if (setsockopt(sockFd, SOL_SOCKET, SO_RCVTIMEO, &ackTimeout, sizeof(ackTimeout)) < 0)
	{
		cout << "Error: OpensslSocket::Send()-->setsockopt() could not set timeout" << endl;
		perror("Errno Message");
		return -1;
	}

	/* loop through each block of the message and send */
	for (int i = 0; i < numBlks; i++)
	{
		/* send current block until ack received */
		do
		{
			ackSeqNum = false;
			memset(sendBlk, 0, MAX_MSG_SIZE);

			/* check if last block */
			if (i == (numBlks - 1))
			{
				msgHeader.msgSize = msgLength % MAX_MSG_SIZE;
				msgHeader.finalBlk = 1;
			}

			/* write message header, message into buffer */
			BundleHeader(sendBlk, msgHeader);
			memcpy(sendBlk + HEADER_SIZE, msg + (i * MAX_MSG_SIZE), msgHeader.msgSize);

			if (sendto(sockFd, sendBlk, msgHeader.msgSize + HEADER_SIZE, 0, (struct sockaddr *)&sendAddr, sendAddrLen) < 0)
			{
				cout << "Error: OpensslSocket::Send()-->sendto()" << endl;
				perror("Errno Message");
				return -1;
			}

			/* receive ack */
			if (recvfrom(sockFd, ack, HEADER_SIZE, 0, (struct sockaddr *)&recvAddr, &recvAddrLen) < 0)
			{
				if (errno == EAGAIN || errno == EWOULDBLOCK)
					continue;
				cout << "Error: OpensslSocket::Send()-->recvfrom() could not receive ack" << endl;
				perror("Errno Message");
				return -1;
			}

			/* check IP of ack, check if ack is correct sequence number */
			inet_ntop(AF_INET, &(recvAddr.sin_addr), recvIP, INET_ADDRSTRLEN);
			if (string(sentIP).compare(recvIP) != 0)
				continue;
			FetchHeader(ack, &recvMsgHeader);
			ackSeqNum = (recvMsgHeader.seqNum == msgHeader.seqNum);

		} while (!ackSeqNum);

		msgHeader.seqNum++;
	}

	/* remove ack timeout on socket */
	ackTimeout.tv_sec = 0;
	ackTimeout.tv_usec = 0;
	if (setsockopt(sockFd, SOL_SOCKET, SO_RCVTIMEO, &ackTimeout, sizeof(ackTimeout)) < 0)
	{
		cout << "Error: OpensslSocket::Send()-->setsockopt() could not remove timeout" << endl;
		perror("Errno Message");
	}

	return 0;
}
void OpensslSocket::GetReceiveMessage(char *buffer, size_t bufferLength)
{
	int length = (receiveBufferLength > bufferLength) ? bufferLength : receiveBufferLength;
	if (receiveBufferGood)
		copy_n(receiveBuffer.begin(), length, buffer);
}

void OpensslSocket::BundleHeader(char *dest, msgHeader_t header)
{
	uint32_t seqNum_N = htonl(header.seqNum);
	uint16_t msgSize_N = htons(header.msgSize);
	uint16_t finalBlk_N = htons(header.finalBlk);

	int msgOffset = sizeof(seqNum_N);
	int finalOffset = msgOffset + sizeof(msgSize_N);

	memcpy(dest, &seqNum_N, sizeof(seqNum_N));
	memcpy(dest + msgOffset, &msgSize_N, sizeof(msgSize_N));
	memcpy(dest + finalOffset, &finalBlk_N, sizeof(finalBlk_N));
}
int OpensslSocket::Receive()
{
	if (!socketGood)
		return -1;

	if (receiveBufferGood)
	{
		receiveBuffer.clear();
		receiveBufferGood = false;
	}

	sockaddr_in senderAddr;
	socklen_t senderAddrLen = sizeof(senderAddr);
	char senderIP[INET_ADDRSTRLEN];
	string originalSenderIP;
	bool firstRecv;
	msgHeader_t msgHeader;
	ssize_t numBytes;
	char blk[BLK_SIZE];
	char ack[HEADER_SIZE];
	uint32_t nextSeqNum;

	memset(&msgHeader, 0, sizeof(msgHeader));
	firstRecv = true;

// receive blocks
	while (!msgHeader.finalBlk)
	{
		/* receive block */
		numBytes = recvfrom(sockFd, blk, BLK_SIZE, 0, (struct sockaddr *)&senderAddr, &senderAddrLen);
		if (numBytes < 0 || numBytes < HEADER_SIZE)
		{
			cout << "Error: OpensslSocket::Receive()-->recvfrom()" << endl;
			perror("Errno Message");
			return -1;
		}

		/* remove header from block */
		FetchHeader(blk, &msgHeader);
		if (msgHeader.msgSize != (numBytes - HEADER_SIZE))
		{
			cout << "Error: OpensslSocket::Receive()-->recvfrom() Partial Block Received" << endl;
			cout << "Message Size should have been " << msgHeader.msgSize + HEADER_SIZE << " but was " << numBytes << endl;
			return -1;
		}

		/* check the sender IP, compare against initial connection */
		/* verify this is the correct sequence number */
		/* if correct, extract message from block */
		inet_ntop(AF_INET, &(senderAddr.sin_addr), senderIP, INET_ADDRSTRLEN);
		if (firstRecv)
		{
			cout << "Inbound connection" << endl;
			nextSeqNum = msgHeader.seqNum + 1;
			originalSenderIP = senderIP;
			firstRecv = false;
			receiveBuffer.insert(receiveBuffer.end(), blk + HEADER_SIZE, blk + numBytes);
			receiveBufferLength = receiveBuffer.size();
		}
		else if (originalSenderIP.compare(senderIP) != 0)
		{
			cout << "Error: OpensslSocket::Receive()-->recvfrom() different IPs original=" << originalSenderIP << " last=" << senderIP << endl;
			return -1;
		}
		else if (msgHeader.seqNum != nextSeqNum)
		{
			msgHeader.seqNum = nextSeqNum;
		}
		else
		{
			nextSeqNum = msgHeader.seqNum + 1;
			receiveBuffer.insert(receiveBuffer.end(), blk + HEADER_SIZE, blk + numBytes);
			receiveBufferLength = receiveBuffer.size();
		}
		// acknowledgement
		BundleHeader(ack, msgHeader);
		if (sendto(sockFd, ack, HEADER_SIZE, 0, (struct sockaddr *)&senderAddr, senderAddrLen) < 0)
		{
			cout << "Error: OpensslSocket::Receive()-->sendto() could not send ack" << endl;
			perror("Errno Message");
			return -1;
		}
	}

	receiveBufferGood = true;
	return receiveBuffer.size();
}


