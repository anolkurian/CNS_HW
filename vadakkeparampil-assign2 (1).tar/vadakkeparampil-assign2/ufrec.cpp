#include <openssl/evp.h>
#include <openssl/kdf.h>
#include <openssl/params.h>
#include <iostream>
#include <cstdio>
#include <stdio.h>
#include <stdlib.h>
#include <cstring>
#include <openssl/conf.h>
#include <openssl/err.h>
#include <string.h>
#include <iostream>
#include <fstream>
#include <sys/stat.h>
#include "OpensslSocket.h"

using std::cout;
using std::endl;
using std::filebuf;
using std::ifstream;
using std::ofstream;
using std::string;

#define L_NUM_ARGS 3
#define D_NUM_ARGS 4
#define D_OPT "-d"
#define L_OPT "-l"

string inputFileName;
string outputFileName;
string type;
string ipAddr;
string sendPort;
string recvPort;
string key;
string port;
bool localMode;
#define ENC_FILE_EXT ".ufsec" /* File extension of encrypted file */
OpensslSocket *opensslSocket;

typedef enum
{
     ERR_NUM_ARGS = 1,
     ERR_OPT = 2,
     ERR_NO_FILE = 3,
     ERR_EXT = 4,
     ERR_FILE_EXISTS = 33
} parseErrorTypes;

// function definitions
void handleErrors(void);
int gcm_decrypt(unsigned char *cT, int cT_len,
                unsigned char *aad, int aad_len,
                unsigned char *tag,
                unsigned char *key,
                unsigned char *iv, int iv_len,
                unsigned char *pT);
void ParseErrorMessage(int errorCode);
int Parse(int numArgs, char **args);
bool ReadFile(const string fileName, unsigned char *fileContent, size_t bufferSize);
bool WriteFile(const string fileName, unsigned char *fileContent, size_t bufferSize);
size_t GetFileSize(const string fileName);

// main
int main(int argc, char **argv)
{
     int parseResult;
     int numBytes;
     int pT_len, cT_len;
     unsigned char cT[2500];
     unsigned char password[100];
     unsigned char key[32];
     parseResult = Parse(argc, argv);
     if (parseResult != 0)
     {
          ParseErrorMessage(parseResult);
          return parseResult;
     }
     if (localMode)
     {
          // key generation
          printf("Enter your password:");
          scanf("%s", password);
          const char *pwd = (const char *)password;
          const unsigned char *salt = reinterpret_cast<const unsigned char *>("SodiumChloride");
          PKCS5_PBKDF2_HMAC(pwd, strlen(pwd), salt, strlen("SodiumChloride"), 4096,
                            EVP_sha3_256(), 32, key);
          // print key in hex
          printf("\n Hec of Key : \n");
          for (size_t i = 0; i < strlen(reinterpret_cast<const char *>(key)); i++)
               printf("%02x", key[i]);
          printf("\n");

          // file size
          cT_len = GetFileSize(inputFileName);
          if (cT_len < 0)
               return -1;

          // read file from local machine
          if (!ReadFile(inputFileName, cT, cT_len))
               return -1;
     }
     else
     {
          // Receive encrypted text
          cout << "Waiting for connections..." << endl;
          opensslSocket = new OpensslSocket(port);

          numBytes = opensslSocket->Receive();
          if (numBytes < 0)
               return -1;
          cout << "Received encrypted file" << endl;

          // Get Cipher text
          cT_len = numBytes;
          opensslSocket->GetReceiveMessage((char *)cT, cT_len);

          // Key Generation
          printf("Enter your password:");
          scanf("%s", password);
          const char *pwd = (const char *)password;
          const unsigned char *salt = reinterpret_cast<const unsigned char *>("SodiumChloride");
          PKCS5_PBKDF2_HMAC(pwd, strlen(pwd), salt, strlen("SodiumChloride"), 4096,
                            EVP_sha3_256(), 32, key);
          // Print Hexadecimal Key
          for (size_t i = 0; i < strlen(reinterpret_cast<const char *>(key)); i++)
               printf("%02x", key[i]);
          printf("\n");
     }

     // Have received cipher text at this point
     // Print Cipher Text in Hex
     printf("Ciphertext in Hex is:\n");
     // BIO_dump_fp (stdout, (const char *)cT, cT_len);
     for (size_t i = 0; i < cT_len; i++)
          printf("%02x", cT[i]);
     printf("\n");

     // Tackle Decryption

     size_t pTLength;
     unsigned char pT[2500];
     unsigned char tag[16];

     // Declare IV
     unsigned char *iv = (unsigned char *)"0123456789012345";
     size_t iv_len = 16;

     // Declare Additional
     unsigned char *additional = (unsigned char *)"The five boxing wizards jump quickly.";

     // Since I havent figured out how to send additional data, IV and Tag with cipher text and use it for decrypting.
     // I am leaving Additional Data and IV for future scope.
     // And reading tag from a file after storing it during encryption.

     // get tag
     ReadFile("generatedtag1.txt", tag, 16);
     printf("\n Generated Tag is:\n");
     BIO_dump_fp(stdout, (const char *)tag, 16);

     // Decryption of CipherText
     pT_len = gcm_decrypt(cT, cT_len,
                                     additional, strlen((char *)additional),
                                     tag,
                                     key, iv, iv_len,
                                     pT);
     printf("%d", pT_len);
     if (pT_len >= 0)
     {
          // Null terminator for printing
          pT[pT_len] = '\0';

          printf("Decrypted text is:\n");
          printf("%s\n", pT);
     }
     else
     {
          printf("Decryption failed\n");
     }

     return 0;
}

// Read , Write , Get File Size Functions.
bool ReadFile(const string fileName, unsigned char *fileContent, size_t bufferSize)
{
     ifstream ifStream;
     filebuf *ifPointer;

     ifStream.open(fileName.c_str(), ifstream::in);
     if (!ifStream.is_open())
     {
          cout << "Error Read File " << endl;
          return false;
     }

     ifPointer = ifStream.rdbuf();
     ifPointer->sgetn((char *)fileContent, bufferSize);

     ifStream.close();
     return true;
}
bool WriteFile(const string fileName, unsigned char *fileContent, size_t bufferSize)
{
     ofstream ofStr;

     ofStr.open(fileName.c_str(), ofstream::out);
     if (!ofStr.is_open())
     {
          cout << "Error Write File " << fileName << endl;
          return false;
     }

     ofStr.write((char *)fileContent, bufferSize);
     ofStr.close();
     return true;
}
size_t GetFileSize(const string fileName)
{
     ifstream ifStream;
     filebuf *ifPointer;
     size_t ifSize;

     ifStream.open(fileName.c_str(), ifstream::in);
     if (!ifStream.is_open())
     {
          cout << "Error getting File Size " << endl;
          return -1;
     }

     ifPointer = ifStream.rdbuf();
     ifSize = ifPointer->pubseekoff(0, ifStream.end, ifStream.in);
     ifPointer->pubseekpos(0, ifStream.in);

     ifStream.close();
     return ifSize;
}

int Parse(int numArgs, char **args)
{
     struct stat buffer;
     int delimeter, length;
     size_t index;
     // argument check
     if ((numArgs != L_NUM_ARGS) && (numArgs != D_NUM_ARGS))
          return ERR_NUM_ARGS;

     // get input file name
     inputFileName.assign(args[1]);

     // get -l or -d
     type.assign(args[2]);

     // -l option
     if ((type.compare(L_OPT) == 0) && (numArgs == L_NUM_ARGS))
     {

          // File Exists check
          if (stat(inputFileName.c_str(), &buffer) != 0)
               return ERR_NO_FILE;

          // find ".ufsec" extension index
          index = inputFileName.find_last_of(ENC_FILE_EXT);
          if (index == string::npos)
               return ERR_EXT;

          // O/P file name => remove extension from input file name
          outputFileName = inputFileName.substr(0, index - 5);

          // File does not exist check
          if (stat(outputFileName.c_str(), &buffer) == 0)
               return ERR_FILE_EXISTS;

          localMode = true;
     }
     /* -d option */
     else if ((type.compare(D_OPT) == 0) && (numArgs == D_NUM_ARGS))
     {
          /* store port */
          port.assign(args[3]);
          outputFileName = inputFileName;
          // File doesnt exist check
          if (stat(outputFileName.c_str(), &buffer) == 0)
               return ERR_FILE_EXISTS;
          localMode = false;
     }
     else
          return ERR_OPT;

     return 0;
}

void ParseErrorMessage(int errorCode)
{
     switch (errorCode)
     {
     case ERR_NUM_ARGS:
          cout << "Error: Format <filename> [-d <port>] [-l]" << endl;
          break;
     case ERR_NO_FILE:
          cout << "Error: Input file does not exist" << endl;
          break;
     case ERR_FILE_EXISTS:
          cout << "Error: Output file exists" << endl;
          break;
     case ERR_OPT:
          cout << "Error:[-d <port>] for network or [-l] for local" << endl;
          break;
     case ERR_EXT:
          cout << "Error: input file must have extension " << ENC_FILE_EXT << endl;
          break;
     }
}

void handleErrors(void)
{
     ERR_print_errors_fp(stderr);
     abort();
}

// code reference from wiki openssl
int gcm_decrypt(unsigned char *cT, int cT_len,
                unsigned char *aad, int aad_len,
                unsigned char *tag,
                unsigned char *key,
                unsigned char *iv, int iv_len,
                unsigned char *pT)
{

     EVP_CIPHER_CTX *ctx;
     int len;
     int pT_len;
     int ret;

     /* Create and initialise the context */
     if (!(ctx = EVP_CIPHER_CTX_new()))
          handleErrors();

     /* Initialise the decryption operation. */
     if (!EVP_DecryptInit_ex(ctx, EVP_aes_256_gcm(), NULL, NULL, NULL))
          handleErrors();

     /* Set IV length. Not necessary if this is 12 bytes (96 bits) */
     if (!EVP_CIPHER_CTX_ctrl(ctx, EVP_CTRL_GCM_SET_IVLEN, iv_len, NULL))
          handleErrors();

     /* Initialise key and IV */
     if (!EVP_DecryptInit_ex(ctx, NULL, NULL, key, iv))
          handleErrors();

     /*
      * Provide any AAD data. This can be called zero or more times as
      * required
      */
     if (!EVP_DecryptUpdate(ctx, NULL, &len, aad, aad_len))
          handleErrors();

     /*
      * Provide the message to be decrypted, and obtain the plaintext output.
      * EVP_DecryptUpdate can be called multiple times if necessary
      */
     if (!EVP_DecryptUpdate(ctx, pT, &len, cT, cT_len))
          handleErrors();
     pT_len = len;

     /* Set expected tag value. Works in OpenSSL 1.0.1d and later */
     if (!EVP_CIPHER_CTX_ctrl(ctx, EVP_CTRL_GCM_SET_TAG, 16, tag))
          handleErrors();

     /*
      * Finalise the decryption. A positive return value indicates success,
      * anything else is a failure - the plaintext is not trustworthy.
      */
     ret = EVP_DecryptFinal_ex(ctx, pT + len, &len);

     /* Clean up */
     EVP_CIPHER_CTX_free(ctx);

     if (ret > 0)
     {
          /* Success */
          pT_len += len;
          return pT_len;
     }
     else
     {
          /* Verify failed */
          return -1;
     }
}