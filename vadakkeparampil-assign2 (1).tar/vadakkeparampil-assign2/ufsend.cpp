#include <openssl/evp.h>
#include <openssl/kdf.h>
#include <openssl/params.h>
#include <iostream>
#include <cstdio>
#include <stdio.h>
#include <stdlib.h>
#include <cstring>
#include <openssl/conf.h>
#include <openssl/err.h>
#include <string.h>
#include <iostream>
#include <fstream>
#include <sys/stat.h>
#include <random>
#include "OpensslSocket.h"
#include <string>
#include <algorithm>

using std::cout;
using std::endl;
using std::filebuf;
using std::ifstream;
using std::ofstream;
using std::string;

#define L_NUM_ARGS 3
#define D_NUM_ARGS 4
#define D_OPT "-d"
#define L_OPT "-l"
#define ONE_PORT "45000"

string inputFileName;
string outputFileName;
string type;
string ipAddr;
string sendPort;
string recvPort;
string key;
bool localMode;
#define ENC_FILE_EXT ".ufsec" /* File extension of encrypted file */
std::random_device rd;
std::mt19937 gen(rd());
OpensslSocket *opensslSocket;

typedef enum
{
     ERR_NUM_PARAMS = 1,
     ERR_OPT = 2,
     ERR_NO_FILE = 3,
     ERR_FILE_EXISTS = 33
} parseErrorTypes;

// function definitions
void handleErrors(void);
int gcm_encrypt(unsigned char *pT, int pT_len,
                unsigned char *aad, int aad_len,
                unsigned char *key,
                unsigned char *iv, int iv_len,
                unsigned char *cT,
                unsigned char *tag);
void ParseErrorMessage(int errCode);
int Parse(int numArgs, char **args);
bool ReadFile(const string fileName, unsigned char *fileContent, size_t bufferSize);
bool WriteFile(const string fileName, unsigned char *fileContent, size_t bufferSize);
size_t GetFileSize(const string fileName);


// main
int main(int argc, char **argv)
{
     size_t pTLength;
     int parseResult;
     int cT_len;
     unsigned char cT[2500];
     unsigned char tag[16];
     unsigned char key[32];
     unsigned char password[100];

     // Get Password
     printf("Enter your password:");
     scanf("%s", password);
     const char *pwd = (const char *)password;

     // Declare Salt
     const unsigned char *salt = reinterpret_cast<const unsigned char *>("SodiumChloride");

     // Generate Key
     PKCS5_PBKDF2_HMAC(pwd, strlen(pwd), salt, strlen("SodiumChloride"), 4096,
                       EVP_sha3_256(), 32, key);
     // Print Key
     printf("Hex of Key : \n");
     for (size_t i = 0; i < strlen(reinterpret_cast<const char *>(key)); i++)
          printf("%02x", key[i]);
     printf("\n \n \n");

     // Declare IV
     unsigned char *iv = (unsigned char *)"0123456789012345";
     size_t iv_len = 16;

     // Declare Additional data
     unsigned char *additional = (unsigned char *)"The five boxing wizards jump quickly.";

     // Parse arguments to find required parameters i.e. => port | mode
     parseResult = Parse(argc, argv);
     if (parseResult != 0)
     {
          ParseErrorMessage(parseResult);
          return parseResult;
     }

     //  make sure sendPort and recvPort are different
     recvPort = (sendPort.compare(ONE_PORT) == 0) ? std::to_string(atoi(ONE_PORT) + 1) : ONE_PORT;
     opensslSocket = new OpensslSocket(recvPort, sendPort);

     // Read Plain Text from File
     pTLength = GetFileSize(inputFileName);
     unsigned char *pT = new unsigned char[pTLength];
     ReadFile(inputFileName, pT, pTLength);

     // Encrypt the plaintext
     cT_len = gcm_encrypt(pT, pTLength,
                                  additional, strlen((char *)additional),
                                  key,
                                  iv, iv_len,
                                  cT, tag);

     // Print Cipher Text in Hex
     printf("Ciphertext in Hex is:\n");
     // BIO_dump_fp (stdout, (const char *)cT, cT_len);
     for (size_t i = 0; i < cT_len; i++)
          printf("%02x", cT[i]);
     printf(" \n \n \n");

     WriteFile("generatedtag1.txt", tag, 16);
     printf("\n Tag is:\n");
     BIO_dump_fp(stdout, (const char *)tag, 16);
     
     // handle -l and -d modes
     if (localMode)
     {
          if (!WriteFile(outputFileName, cT, cT_len))
               return -1;
          printf("Encrypted %s to %s (%lu bytes).\n", inputFileName.c_str(), outputFileName.c_str(), cT_len);
     }
     else
     {
          printf("Encrypted %s to %s (%lu bytes).\n", inputFileName.c_str(), outputFileName.c_str(), cT_len);
          cout << "Transmitting to " << ipAddr << ":" << sendPort << endl;
          if (opensslSocket->Send(ipAddr, (char *)cT, cT_len) != 0)
               return -1;
          cout << "Successfully Sent" << endl;
     }
     return 0;
}

// int random(int low, int high)
// {
//      std::uniform_int_distribution<> dist(low, high);
//      return dist(gen);
// }


// Read , Write , Get File Size Functions.
bool ReadFile(const string fileName, unsigned char *fileContent, size_t bufferSize)
{
     ifstream ifStream;
     filebuf *ifPointer;

     ifStream.open(fileName.c_str(), ifstream::in);
     if (!ifStream.is_open())
     {
          cout << "Error Read File Function " << fileName << endl;
          return false;
     }

     ifPointer = ifStream.rdbuf();
     ifPointer->sgetn((char *)fileContent, bufferSize);

     ifStream.close();
     return true;
}
bool WriteFile(const string fileName, unsigned char *fileContent, size_t bufferSize)
{
     ofstream ofStr;

     ofStr.open(fileName.c_str(), ofstream::out);
     if (!ofStr.is_open())
     {
          cout << "Error Write File Function " << fileName << endl;
          return false;
     }

     ofStr.write((char *)fileContent, bufferSize);
     ofStr.close();
     return true;
}
size_t GetFileSize(const string fileName)
{
     ifstream ifStream;
     filebuf *ifPointer;
     size_t ifSize;

     ifStream.open(fileName.c_str(), ifstream::in);
     if (!ifStream.is_open())
     {
          cout << "Error getting size of " << fileName << endl;
          return -1;
     }

     ifPointer = ifStream.rdbuf();
     ifSize = ifPointer->pubseekoff(0, ifStream.end, ifStream.in);
     ifPointer->pubseekpos(0, ifStream.in);

     ifStream.close();
     return ifSize;
}

// Parse Error Message
void ParseErrorMessage(int errCode)
{
     switch (errCode)
     {
     case ERR_NUM_PARAMS: cout << "Error: Format is <filename> [-d <IPaddr>:<port>] [-l]" << endl;
          break;
     case ERR_NO_FILE: cout << "Error: I/P file does not exist" << endl;
          break;
     case ERR_FILE_EXISTS: cout << "Error: O/P file exists" << endl;
          break;
     case ERR_OPT: cout << "Error: [-d <IPaddr>:<port>] for network // [-l] for local" << endl;
          break;
     }
}

int Parse(int numArgs, char **args)
{
     struct stat buffer;
     int delimeter, length;
     string ipAddr_port;

     // check  parameters 
     if ((numArgs != L_NUM_ARGS) && (numArgs != D_NUM_ARGS))
          return ERR_NUM_PARAMS;

     // get input file name and generate output file name
     inputFileName.assign(args[1]);
     outputFileName = inputFileName;
     outputFileName.append(ENC_FILE_EXT);

     // File exists check
     if (stat(inputFileName.c_str(), &buffer) != 0)
          return ERR_NO_FILE;

     // -l or -d save
     type.assign(args[2]);

     // handle -l
     if ((type.compare(L_OPT) == 0) && (numArgs == L_NUM_ARGS))
     {
          // Check output file exists or not
          if (stat(outputFileName.c_str(), &buffer) == 0)
               return ERR_FILE_EXISTS;

          localMode = true;
     }
     // handle -d
     else if ((type.compare(D_OPT) == 0) && (numArgs == D_NUM_ARGS))
     {
          // ipaddr store
          ipAddr_port.assign(args[3]);

          // check if min 9 length
          if (ipAddr_port.size() < 9)
               return ERR_OPT;

          // find ":" seperator for port
          delimeter = ipAddr_port.find(':');
          if (delimeter == string::npos)
               return ERR_OPT;

          // assign ip and port
          ipAddr = ipAddr_port.substr(0, delimeter);
          sendPort = ipAddr_port.substr(delimeter + 1, ipAddr_port.size());

          localMode = false;

     }
     else
          return ERR_OPT;

     return 0;
}

void handleErrors(void)
{
     ERR_print_errors_fp(stderr);
     abort();
}


// Code reference from wiki openssl
int gcm_encrypt(unsigned char *pT, int pT_len,
                unsigned char *aad, int aad_len,
                unsigned char *key,
                unsigned char *iv, int iv_len,
                unsigned char *cT,
                unsigned char *tag)
{
     EVP_CIPHER_CTX *ctx;

     int len;

     int cT_len;

     /* Create and initialise the context */
     if (!(ctx = EVP_CIPHER_CTX_new()))
          handleErrors();

     /* Initialise the encryption operation. */
     if (1 != EVP_EncryptInit_ex(ctx, EVP_aes_256_gcm(), NULL, NULL, NULL))
          handleErrors();

     /*
      * Set IV length if default 12 bytes (96 bits) is not appropriate
      */
     if (1 != EVP_CIPHER_CTX_ctrl(ctx, EVP_CTRL_GCM_SET_IVLEN, iv_len, NULL))
          handleErrors();

     /* Initialise key and IV */
     if (1 != EVP_EncryptInit_ex(ctx, NULL, NULL, key, iv))
          handleErrors();

     /*
      * Provide any AAD data. This can be called zero or more times as
      * required
      */
     if (1 != EVP_EncryptUpdate(ctx, NULL, &len, aad, aad_len))
          handleErrors();

     /*
      * Provide the message to be encrypted, and obtain the encrypted output.
      * EVP_EncryptUpdate can be called multiple times if necessary
      */
     if (1 != EVP_EncryptUpdate(ctx, cT, &len, pT, pT_len))
          handleErrors();
     cT_len = len;

     /*
      * Finalise the encryption. Normally ciphertext bytes may be written at
      * this stage, but this does not occur in GCM mode
      */
     if (1 != EVP_EncryptFinal_ex(ctx, cT + len, &len))
          handleErrors();
     cT_len += len;

     /* Get the tag */
     if (1 != EVP_CIPHER_CTX_ctrl(ctx, EVP_CTRL_GCM_GET_TAG, 16, tag))
          handleErrors();

     /* Clean up */
     EVP_CIPHER_CTX_free(ctx);

     return cT_len;
}